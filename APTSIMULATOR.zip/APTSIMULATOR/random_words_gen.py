import random
import re

animals_list = [
    'alligators',
    'ants',
    'anteaters',
    'antelopes',
    'armadillos',
    'elephants',
    'bears',
    'hornets',
    'baboons',
    'camels',
    'owls',
    'barracudas',
    'terriers',
    'buffalos',
    'bulldogs',
    'bullfrogs',
    'butterflies',
    'caimans',
    'cats',
    'caterpillars',
    'chickens',
    'chihuahuas',
    'chimpanzees',
    'chipmunks',
    'leopards',
    'drevers',
    'donkeys',
    'ducks',
    'dolphins',
    'eagles',
    'earwigs',
    'gorillas',
    'seals',
    'penguins',
    'fishes',
    'flamingos',
    'flies',
    'squirells',
    'fox'
]

adjectives_list = [
    'fine',
    'faithful',
    'fantastic',
    'fancy',
    'adorable',
    'adventurous',
    'aggressive',
    'better',
    'beautiful',
    'bad',
    'awful',
    'average',
    'attractive',
    'ashamed',
    'arrogant',
    'anxious',
    'annoying',
    'annoyed',
    'angry',
    'amused',
    'alive',
    'alert',
    'agreeable',
    'bewildered',
    'black',
    'bloody',
    'blue',
    'blushing',
    'bored',
    'brainy',
    'brave',
    'breakable',
    'bright',
    'busy',
    'calm',
    'careful',
    'cautious',
    'charming',
    'cheerful',
    'clean',
    'clever',
    'clumsy',
    'colorful',
    'combative',
    'comfortable',
    'concerned',
    'confused',
    'courageous',
    'cooperative',
    'crazy',
    'creepy',
    'cruel',
    'curious',
    'cute',
    'dangerous',
    'dark',
    'dead',
    'defeated',
    'delightful',
    'depressed',
    'different',
    'dizzy',
    'doubtful',
    'dull',
    'elegant',
    'embarrassed',
    'enchanting',
    'enthusiastic',
    'energetic',
    'evil',
    'excited',
    'expensive',
    'fancy',
    'faithful',
    'fantastic',
    'fine',
    'foolish',
    'fierce',
    'famous',
    'funny',
    'gentle',
    'good',
    'glorious',
    'gorgeous',
    'grumpy',
    'handsome',
    'happy',
    'healthy',
    'homeless',
    'hungry',
    'innocent',
    'itchy',
    'jealous',
    'lazy',
    'lively',
    'lonely',
    'lucky',
    'mysterious',
    'nasty',
    'naughty',
    'nice',
    'odd',
    'outrageous',
    'poor',
    'powerful',
    'precious',
    'proud',
    'rich',
    'scary',
    'selfish',
    'shy',
    'shiny',
    'silly',
    'sleepy',
    'smiling',
    'stupid',
    'successful',
    'strange',
    'talented',
    'tasty',
    'tense',
    'terrible',
    'thankful',
    'tired',
    'ugly',
    'uninterested',
    'victorious',
    'wicked',
    'wild',
    'worried'
]

threat_actor_types = [
    'activist',
    'competitor',
    'crime-syndicate',
    'criminal',
    'hacker',
    'insider-accidental',
    'insider-disgruntled',
    'nation-state',
    'sensationalist',
    'spy',
    'terrorist',
    'unknown'
]

threat_actor_roles = [
    'agent',
    'director',
    'independent',
    'infraestructure-architect',
    'infrastructure-operator',
    'malware-author',
    'sponsor'
]

threat_actor_sophistication = [
    'none',
    'minimal',
    'intermediate',
    'advanced',
    'expert',
    'innovator',
    'strategic'
]

threat_actor_motivation = [
    'accidental',
    'coercion',
    'dominance',
    'ideology',
    'notoriety',
    'organizational-gain',
    'personal-gain',
    'personal-satisfaction',
    'revenge',
    'unpredictable'
]

attack_resource_level = [
    'individual',
    'club',
    'contest',
    'team',
    'organization',
    'government'
]

regions = [
    'africa',
    'eastern-africa',
    'middle-africa',
    'northern-africa',
    'southern-africa',
    'western-africa',
    'americas',
    'caribbean',
    'central-america',
    'latin-america-caribbean',
    'northern-america',
    'south-america',
    'asia',
    'central-asia',
    'eastern-asia',
    'southern-asia',
    'south-eastern-asia',
    'western-asia',
    'europe',
    'eastern-europe',
    'northern-europe',
    'southern-europe',
    'western-europe',
    'oceania',
    'antarctica',
    'australia-new-zealand',
    'melanesia',
    'micronesia',
    'polynesia'
]

addresses = [
    'Calle del mañana',
    'Avda de la tranquilidad',
    'Sitio donde no se hacen cosas malas',
    'Avda de la oliva',
    'Calle del hacker',
    'Paseo de la habana',
    'Avda de las cosas malas',
    'Paseo del anónimo',
    'Rotonda de la felicidad',
    'Avda del rey gordo',
    'Calle de la sastrería',
    'Paseo de la princesa coja',
    'Avda de la sal',
    'Calle del ordenador',
    'Paseo de la avellana',
    'Calle del ruido',
    'Avda de los secretos',
]


def get_random_address():
    '''
    Esta función genera una dirección aleatoria
    :return: Devuelve un string con la dirección generada por un string elegido aleatoriamente de la lista de direcciones
    y un número aleatorio que indica el número de la dirección.
    '''
    random_int = str(random.randint(1, 30))
    random_address = str(random.choice(addresses))
    return random_address + " ," + random_int


def get_random_region():
    '''
    Esta función selecciona del listado de regiones, una aleatoriamente y la devuelve.
    :return: string con la region aleatoria generada
    '''
    x = random.choice(regions)
    result = re.sub('[\"\'\[\]]', '', x)
    return result


def get_threat_actor_motivation():
    '''
    Esta función selecciona del listado de motivaciones de los actores de amenaza, una aleatoriamente y la devuelve.
    :return: string con la motivación aleatoria generada
    '''
    return str(random.choice(threat_actor_motivation))


def get_attack_level():
    '''
    Esta función selecciona del listado de recurso de nivel de ataque uno aleatoriamente y lo devuelve
    :return: string con el recurso de nivel aleatorio generado
    '''
    return str(random.choice(attack_resource_level))


def get_threat_actor_sophistication():
    '''
    Esta función selecciona del listado de sofisticación del actor de amenazas, uno aleatoriamente y lo deuvelve
    :return: string con la sofisticación aleatoria generada.
    '''
    return str(random.choice(threat_actor_sophistication))


def get_threat_actor_role():
    '''
    Esta función selecciona del listado de roles del actor de amenazas, uno aleatoriamente y lo devuelve
    :return: string con el rol aleatorio generado
    '''
    return str(random.choice(threat_actor_roles))


def get_threat_actor_type():
    '''
    Esta función selecciona del listado de tipo de actor de amenazas, uno aleatoriamente y lo devuelve
    :return: string con el tipo de actor de amenaza aleatorio generado
    '''
    return str(random.choice(threat_actor_types))


def pick_two_random_words():
    '''
    Esta función elige dos palabras aleatorias de la lista de adjectivos y de nombres de animales y las combina para
    crear el nombre del grupo APT aleatorio
    :return: string con el nombre del grupo APT aleatorio generado
    '''
    y = str(random.choice(adjectives_list))
    x = str(random.choice(animals_list))
    aptname = y + " " + x
    return aptname
