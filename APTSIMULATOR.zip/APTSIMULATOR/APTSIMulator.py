print("inicio de ejecucion apt simulator")
