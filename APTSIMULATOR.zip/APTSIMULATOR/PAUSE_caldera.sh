#!/bin/bash
cd /home/cobra/Apt_simulator/APTSIMULATOR
curl -X 'PATCH' -H "KEY:ADMIN123" 'http://0.0.0.0:8888/api/v2/operations/d52c1e83-e7ce-4aad-8388-d60aec1f03cc' -d '{"state": "paused", "auto_close": true}'
sed -i 's/False/True/g' .env
