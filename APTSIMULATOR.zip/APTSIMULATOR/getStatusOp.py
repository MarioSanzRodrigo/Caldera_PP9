#Get status of stages in an operation
import main
import subprocess
import re


def getOperationStatus(operationID, objective):
    subprocess.check_output("curl -X 'GET' " + '-H "KEY:ADMIN123" ' + "'http://localhost:8888/api/v2/operations/" + operationID + "' -H 'accept: application/json' >> informe.json", shell=True)
    statusFile = subprocess.check_output('cat informe.json', shell=True)
    statusFile = str(statusFile)
    matches = re.findall(r'status....',statusFile)
    matches.pop(0)
    print(matches[objective-1])